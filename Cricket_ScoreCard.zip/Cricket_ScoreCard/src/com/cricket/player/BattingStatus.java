package com.cricket.player;

public enum BattingStatus {
	YETTOBAT, BATTING, OUT
}
