package com.cricket.team;

public enum TeamStatus {
	BATTING, BOWLING
}
